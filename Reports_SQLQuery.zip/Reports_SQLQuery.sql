----------------------------------------------------------------------Report1
create proc stInfo
as
begin
   select s.st_id,(s.Fname+' '+s.Lname) as FullName, s.Age, s.City, s.total_grade,d.DeptName 
   from Students s inner join st_dep sd
   on sd.st_id = s.st_id
   inner join Department d
   on d.Did = sd.Did
   order by sd.Did
end

stInfo

-----------------------------------------------------------------------Report2
create proc studentGrades @stid intas   begin try    select (s.Fname + ' '+ s.Lname) as fullname, c.Crs_name,crs_st_grade 	from Students s inner join  st_cour st	on s.st_id = st.st_id	inner join Courses c	on c.Crs_id = st.crs_id	where s.st_id = @stid  end try  begin catch    SELECT ERROR_MESSAGE() AS Error  end catch
 studentGrades 5

 ------------------------------------------------------------------------Report3
 create proc instructorCourse @intsID intas   begin try    select (i.Fname + ' '+ i.Lname) as fullname, c.Crs_name, c.count_Students 	from Instructors i 	inner join Courses c	on i.SSN = c.ins_ssn	where i.SSN = @intsID  end try  begin catch    select ERROR_MESSAGE() AS Error  end catch

instructorCourse 3

--------------------------------------------------------------------------Report4
create proc CourseTopic @crsid nvarchar(10)as   begin try     select c.Crs_name , t.top_name 	from Courses c inner join Topics t	on c.Crs_id = t.crs_id	where c.Crs_id = @crsid  end try  begin catch    select ERROR_MESSAGE() AS Error  end catchCourseTopic C101

----------------------------------------------------------------------------Report5
create proc ExamQuestions (@examid int)
as 

   begin try
     select e.Exam_id , Q.Q_desc
	 from Exams e
	 inner join exam_q qe
	 on e.Exam_id= qe.exam_id
	 inner join Qustions q
	 on q.Qid= qe.Q_id
	 where e.Exam_id = @examid
   end try
   begin catch
     select ERROR_MESSAGE() as error
   end catch

   ExamQuestions 2

-----------------------------------------------------------------------------Report6
create proc QandA (@examid int, @stid int)
as
  begin try
     select Q_desc, a.st_ans 
	 from Students s inner join St_Answers a
	 on s.st_id = a.st_id
	 inner join Qustions q
	 on q.Qid=a.Q_id
	 where a.Exam_id = @examid and s.st_id = @stid
  end try
  begin catch
     select ERROR_MESSAGE() as error
  end catch

QandA 1 , 1

-------------------------------------------------------------------------------------------------------Report7
create proc deptTable
as
begin
    select d.Did, d.DeptName, count(SSN) as Num_Of_Instructors
	from Department d
	inner join Instructors i
	on d.Did = i.Did
	group by d.Did, d.DeptName
end

deptTable
-------------------------------------------------------------------------------------------------------Report8
create proc crsTable
as
begin
    select c.Crs_id,c.Crs_name, count(sc.st_id) as Num_Of_Students
	from st_Cour sc
	inner join Courses c
	on sc.crs_id = c.Crs_id
	group by c.Crs_id, c.Crs_name
end

crsTable

-------------------------------------------------------------------------------------------------------Report9
create proc studGender 
as
  begin
       select d.DeptName, count(*) as totalStudents, 
	   count(case when s.Gender='M' then 1 end) as male,
       count(case when s.Gender='F' then 1 end) as female
	   from Students s inner join st_dep st
	   on s.st_id=st.st_id
	   inner join Department d
	   on st.Did=d.Did
	   group by d.DeptName
  end

 studGender